function hideAllLists() {
    var listsToHide = document.querySelectorAll("#mobileList, #laptopList,#tvList");
    listsToHide.forEach(function (list) {
        list.innerHTML = "";
        list.style.display = "none";
    });
}
var mobileItems = [
    { name: "SamSung galaxy S23 ultra",price:"Price:1,24,999",price1:124999, id: 1 },
    { name: "Apple 15pro max",price:"Price:1,57,999",price1:157999, id: 2 },
    { name: "Oneplus 11",price:"Price:69,999",price1:69999, id: 3 }
];         
var laptopItems = [
    { name: "Asus vivobook",price:"Price: 75,999",price1:75999, id: 4 },
    { name: "MacBook Air",price:"Price: 1,29,999",price1:129999, id: 5 },
    { name: "Dell G15",price:"Price: 72,499",price1:72499, id: 6 }
    // Add your actual laptop items with their IDs
];
var tvItems = [
    { name: "Samsung QLED 4K",price:"Price: 95,999",price1:95999, id: 7 },
    { name: "VU OLED FULLHD SAMRT TV",price:"Price: 55,999",price1:55999, id: 8 },
    { name: "SONY ULTRA QLED READYK SAMRT TV",price:"Price: 1,19,999",price1:119999, id: 9 }
    // Add your actual TV items with their IDs
];
            
function displayMobiles() {
    hideAllLists();
    var mobileList = document.getElementById("mobileList");
    mobileList.innerHTML = "";

    mobileItems.forEach(function (item) {
        var li = document.createElement("li");
        li.className = "mobileItem";
        var itemName = document.createTextNode(item.name);
        var itemPrice = document.createTextNode(item.price);
        li.appendChild(itemName);
        li.appendChild(document.createElement("br"))
        li.appendChild(itemPrice);
        li.appendChild(document.createElement("br"))
        var button = document.createElement("button");
        button.textContent = "Add to Cart"; // Corrected typo here
        button.onclick = function () {
            
            addToCart(item.id);
        };

        li.appendChild(button);
        mobileList.appendChild(li);
    });

    // Show only the mobile list
    mobileList.style.display = "block";
}
            
            
            function displayLaptops() {
                hideAllLists();
                var laptopList = document.getElementById("laptopList");
                laptopList.innerHTML = "";
            
            
                laptopItems.forEach(function (item) {
                    var li = document.createElement("li");
                    li.className = "laptopItem";
            
                    var itemName = document.createTextNode(item.name);
                    var itemPrice = document.createTextNode(item.price);
                    li.appendChild(itemName);
                    li.appendChild(document.createElement("br"))
                    li.appendChild(itemPrice);
                    li.appendChild(document.createElement("br"))
                    var button = document.createElement("button");
                    button.textContent = "Add to Cart"; // Corrected typo here
                    button.onclick = function () {
                        // Handle adding the item to cart based on its ID
                        addToCart(item.id);
                    };
            
                    li.appendChild(button);
                    laptopList.appendChild(li);
                });
            
                // Show only the laptop list
                laptopList.style.display = "block";
            }
            
            function displayTVs() {
                hideAllLists();
                var tvList = document.getElementById("tvList");
                tvList.innerHTML = "";
            
            
                tvItems.forEach(function (item) {
                    var li = document.createElement("li");
                    li.className = "tvItem";
                    var itemName = document.createTextNode(item.name);
                    var itemPrice = document.createTextNode(item.price);
                    li.appendChild(itemName);
                    li.appendChild(document.createElement("br"))
                    li.appendChild(itemPrice);
                    li.appendChild(document.createElement("br"))
                    var button = document.createElement("button");
                    button.textContent = "Add to Cart"; // Corrected typo here
                    button.onclick = function () {
                        addToCart(item.id);
                    };
            
                    li.appendChild(button);
                    tvList.appendChild(li);
                });
            
                // Show only the TV list
                tvList.style.display = "block";
            }
            var cartCounter = 0; // Counter to track S.No
            var totalAmount = 0; // Variable to store the total amount

        function updateTotalAmount() {
            var totalCell = document.getElementById('demo');
            totalCell.innerHTML = `Total Price: ${totalAmount}`;
        }
            function addToCart(id) {
                var itemToAdd = null;
                var itemType = ''; // To identify the type of item (mobile, laptop, or TV)
        
                // Check in mobileItems
                itemToAdd = mobileItems.find(item => item.id === id);
                if (itemToAdd) {
                    itemType = 'Mobile';
                } else {
                    // Check in laptopItems
                    itemToAdd = laptopItems.find(item => item.id === id);
                    if (itemToAdd) {
                        itemType = 'Laptop';
                    } else {
                        // Check in tvItems
                        itemToAdd = tvItems.find(item => item.id === id);
                        if (itemToAdd) {
                            itemType = 'TV';
                        }
                    }
                }
        
                if (itemToAdd) {
                    var table = document.getElementById('kartitems');
                    var row = table.insertRow(-1); // Append row at the end of the table
                    var productName = itemToAdd.name;
                    var productPrice = itemToAdd.price1;
        
                    var cell1 = row.insertCell(0); // S.No
                    var cell2 = row.insertCell(1); // Product
                    var cell3 = row.insertCell(2); // Price
        
                    cartCounter++; // Increment the counter for each new row
                    cell1.innerHTML = cartCounter; // Assign the counter value to S.No
                    cell2.innerHTML = productName; // Assign product name to Product cell
                    cell3.innerHTML = productPrice; // Assign product price to Price cell
        
                    console.log(`Added ${productName} (${itemType}) to cart. Price: ${productPrice}`);
                } else {
                    console.log("Item not found");
                }
                totalAmount += productPrice;
                updateTotalAmount();
            }
            function redirectToAddressPage() {
                console.log("Redirecting...");
                window.location.href = "Addresspage.html";
                return false; // Prevent default link behavior
            }
            